package com.instafocus

import android.accessibilityservice.AccessibilityService
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Focus overlay for Instagram.
 *
 * Important implementation detail: accessibility events are also generated while our
 * own accessibility overlay is present. We must NOT treat those events as leaving
 * Instagram, otherwise the overlay is removed and immediately recreated, causing
 * the visible blinking seen in the previous build.
 */
class InstaAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private val views = mutableListOf<BlockView>()

    private var instagramForeground = false
    private var mode = Mode.NONE
    private var searchHasQuery = false
    private var allowSharedViewer = false
    private var lastApplied: OverlaySpec = OverlaySpec.NONE

    private enum class Mode { NONE, HOME, REELS, SEARCH, MESSAGES, OTHER }

    private data class OverlaySpec(
        val kind: Kind,
        val drawQuote: Boolean = false,
        val width: Int = 0,
        val height: Int = 0
    ) {
        enum class Kind { NONE, HOME, REELS, SEARCH }
        companion object { val NONE = OverlaySpec(Kind.NONE) }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceInfo = serviceInfo.apply {
            flags = flags or android.accessibilityservice.AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
        }
        val root = rootInActiveWindow
        instagramForeground = root?.packageName?.toString() == INSTAGRAM
        scheduleRefresh(0)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val eventPackage = event.packageName?.toString() ?: return

        // Our own TYPE_ACCESSIBILITY_OVERLAY can produce accessibility events. Ignore them;
        // they are not evidence that Instagram stopped being foreground.
        if (eventPackage == applicationContext.packageName) return

        if (eventPackage != INSTAGRAM) {
            if (instagramForeground) {
                instagramForeground = false
                mode = Mode.NONE
                searchHasQuery = false
                allowSharedViewer = false
                applyOverlay(OverlaySpec.NONE)
            }
            return
        }

        instagramForeground = true
        scheduleRefresh(140)
    }

    override fun onInterrupt() = Unit

    private fun scheduleRefresh(delay: Long) {
        handler.removeCallbacksAndMessages(REFRESH_TOKEN)
        handler.postAtTime({ refresh() }, REFRESH_TOKEN, android.os.SystemClock.uptimeMillis() + delay)
    }

    private fun refresh() {
        if (!instagramForeground) return

        val root = rootInActiveWindow
        val state = detectMode(root)
        val detected = state.first
        if (detected != Mode.NONE) {
            // A Reel opened directly from a DM can be viewed. We keep this exception
            // only for the immediate Messages -> Reels transition.
            if (mode == Mode.MESSAGES && detected == Mode.REELS) {
                allowSharedViewer = true
            } else if (detected == Mode.MESSAGES || detected == Mode.HOME || detected == Mode.SEARCH) {
                allowSharedViewer = false
            }
            mode = detected
        }
        searchHasQuery = state.second

        val spec = desiredOverlaySpec()
        applyOverlay(spec)
    }

    private fun desiredOverlaySpec(): OverlaySpec {
        val dm = resources.displayMetrics
        val w = dm.widthPixels
        val h = dm.heightPixels

        return when (mode) {
            Mode.HOME -> if (prefs.getBoolean("home", true)) {
                OverlaySpec(OverlaySpec.Kind.HOME, width = w, height = h)
            } else OverlaySpec.NONE

            Mode.REELS -> if (prefs.getBoolean("reels", true) && !allowSharedViewer) {
                OverlaySpec(OverlaySpec.Kind.REELS, width = w, height = h)
            } else OverlaySpec.NONE

            Mode.SEARCH -> if (prefs.getBoolean("search", true) && !searchHasQuery) {
                OverlaySpec(
                    OverlaySpec.Kind.SEARCH,
                    drawQuote = prefs.getBoolean("quote", true),
                    width = w,
                    height = h
                )
            } else OverlaySpec.NONE

            else -> OverlaySpec.NONE
        }
    }

    private fun detectMode(root: AccessibilityNodeInfo?): Pair<Mode, Boolean> {
        if (root == null) return Mode.NONE to false

        val nodes = ArrayList<AccessibilityNodeInfo>(400)
        collect(root, nodes, 0)

        var reels = false
        var search = false
        var home = false
        var messages = false
        var query = false

        for (n in nodes) {
            val raw = n.text?.toString()?.trim().orEmpty()
            val cd = n.contentDescription?.toString()?.trim().orEmpty()
            val text = "$raw $cd".lowercase()

            if (text == "reels" || (text.contains("reels") && n.isSelected)) reels = true
            if (text == "search" || text.contains("search and explore") || text.contains("search tab")) search = true
            if (text == "home" || text.contains("home tab")) home = true
            if (text.contains("messages") || text.contains("direct")) messages = true
            if (n.isEditable && raw.isNotBlank()) query = true
        }

        val result = when {
            reels && isLikelyReels(nodes) -> Mode.REELS
            search && isLikelySearch(nodes) -> Mode.SEARCH
            messages && isLikelyMessages(nodes) -> Mode.MESSAGES
            home -> Mode.HOME
            else -> Mode.NONE
        }
        return result to query
    }

    private fun isLikelyReels(nodes: List<AccessibilityNodeInfo>): Boolean = nodes.count {
        val t = ((it.text?.toString().orEmpty()) + " " + (it.contentDescription?.toString().orEmpty())).lowercase()
        t.contains("reels") || t.contains("likes") || t.contains("comments") || t.contains("audio")
    } >= 2

    private fun isLikelySearch(nodes: List<AccessibilityNodeInfo>): Boolean = nodes.any {
        val t = ((it.text?.toString().orEmpty()) + " " + (it.contentDescription?.toString().orEmpty())).lowercase()
        t.contains("search") && (it.isFocused || it.isEditable)
    } || nodes.any { it.text?.toString()?.lowercase()?.contains("for you") == true }

    private fun isLikelyMessages(nodes: List<AccessibilityNodeInfo>): Boolean = nodes.count {
        val t = ((it.text?.toString().orEmpty()) + " " + (it.contentDescription?.toString().orEmpty())).lowercase()
        t.contains("message") || t.contains("chat")
    } >= 2

    private fun collect(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>, depth: Int) {
        if (depth > 18 || out.size > 400) return
        out.add(node)
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { collect(it, out, depth + 1) }
        }
    }

    /**
     * Only touch the window manager when the desired overlay actually changed.
     * Recreating windows on every Instagram accessibility event was the source of the blink.
     */
    private fun applyOverlay(spec: OverlaySpec) {
        if (spec == lastApplied) return

        clearOverlays()
        lastApplied = spec

        if (spec.kind == OverlaySpec.Kind.NONE) return

        when (spec.kind) {
            OverlaySpec.Kind.HOME -> {
                // Keep the top Stories area usable. Block the feed below it.
                addBlock(0, (spec.height * 0.245f).toInt(), spec.width, (spec.height * 0.91f).toInt(), "home-feed")
                // Block the Reels bottom-nav target without covering the other nav buttons.
                addBlock((spec.width * 0.20f).toInt(), (spec.height * 0.91f).toInt(), (spec.width * 0.40f).toInt(), spec.height, "reels-nav")
            }

            OverlaySpec.Kind.REELS -> {
                addBlock(0, 0, spec.width, spec.height, "reels-full")
            }

            OverlaySpec.Kind.SEARCH -> {
                // Leave the search field above this region interactive.
                addBlock(0, (spec.height * 0.20f).toInt(), spec.width, (spec.height * 0.46f).toInt(), "search-suggestions", spec.drawQuote)
            }

            OverlaySpec.Kind.NONE -> Unit
        }
    }

    private fun addBlock(left: Int, top: Int, right: Int, bottom: Int, id: String, drawQuote: Boolean = false) {
        if (right <= left || bottom <= top) return

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = BlockView(drawQuote)
        val params = WindowManager.LayoutParams(
            right - left,
            bottom - top,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = left
            y = top
            title = "InstaFocus:$id"
        }

        try {
            wm.addView(view, params)
            views += view
        } catch (_: Exception) {
            // If Android rejects a window, don't retry it on every accessibility event.
        }
    }

    private fun clearOverlays() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        views.toList().forEach { view ->
            try { wm.removeViewImmediate(view) } catch (_: Exception) { }
        }
        views.clear()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        clearOverlays()
        super.onDestroy()
    }

    private inner class BlockView(private val drawQuote: Boolean) : View(this@InstaAccessibilityService) {
        private val quotePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var downX = 0f
        private var downY = 0f

        init {
            setBackgroundColor(currentSurface())
            isClickable = true
            isFocusable = false
            quotePaint.typeface = Typeface.DEFAULT_BOLD
            setOnTouchListener { _, _ -> true }
        }

        private fun currentSurface(): Int {
            val dark = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES
            return if (dark) Color.rgb(13, 14, 17) else Color.WHITE
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            if (!drawQuote) return

            val dark = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES
            quotePaint.textAlign = Paint.Align.CENTER
            quotePaint.color = if (dark) Color.WHITE else Color.rgb(25, 25, 28)

            val cx = width / 2f
            quotePaint.textSize = (width * .052f).coerceIn(25f, 40f)
            canvas.drawText("Protect your attention.", cx, height * .43f, quotePaint)

            quotePaint.textSize = (width * .036f).coerceIn(18f, 27f)
            canvas.drawText("Search with purpose, then leave.", cx, height * .58f, quotePaint)

            quotePaint.color = Color.rgb(131, 58, 180)
            quotePaint.textSize = (width * .033f).coerceIn(17f, 25f)
            canvas.drawText("InstaFocus", cx, height * .75f, quotePaint)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (mode == Mode.REELS && !allowSharedViewer) {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX
                        downY = event.rawY
                    }
                    MotionEvent.ACTION_UP -> {
                        val dx = event.rawX - downX
                        val dy = kotlin.math.abs(event.rawY - downY)
                        if (downX < 70f && dx > 110f && dy < 140f) {
                            performGlobalAction(GLOBAL_ACTION_BACK)
                        }
                    }
                }
            }
            return true
        }
    }

    private fun packageName(): String = applicationContext.packageName

    companion object {
        private const val INSTAGRAM = "com.instagram.android"
        private val REFRESH_TOKEN = Any()
    }
}
