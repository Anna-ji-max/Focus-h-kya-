package com.instafocus

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        if (!::statusText.isInitialized) return
        updateStatus()
    }

    private lateinit var statusText: TextView

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(24))
        }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "InstaFocus"
            textSize = 34f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        root.addView(title, lp())

        val subtitle = TextView(this).apply {
            text = "Keep Instagram social, remove the infinite scroll."
            textSize = 17f
            setTextColor(Color.LTGRAY)
        }
        root.addView(subtitle, lp(0, 8))

        statusText = TextView(this).apply {
            textSize = 15f
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(Color.rgb(35, 35, 42))
        }
        root.addView(statusText, lp(0, 20))

        addSwitch(root, "Block Home feed", "home", true)
        addSwitch(root, "Block Reels", "reels", true)
        addSwitch(root, "Hide Search suggestions", "search", true)
        addSwitch(root, "Show motivational quote in Search", "quote", true)

        val accessibility = Button(this).apply {
            text = "1. Enable Accessibility Service"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        root.addView(accessibility, lp(0, 22))

        val note = TextView(this).apply {
            text = "The service only activates when Instagram is the foreground app. Stories and direct messages stay usable; blocked areas consume touches so they cannot be scrolled."
            textSize = 14f
            setTextColor(Color.GRAY)
            setPadding(0, dp(16), 0, 0)
        }
        root.addView(note, lp())

        window.decorView.setBackgroundColor(Color.rgb(14, 14, 18))
        updateStatus()
    }

    private fun addSwitch(parent: LinearLayout, label: String, key: String, default: Boolean) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(10))
        }
        val text = TextView(this).apply {
            this.text = label
            textSize = 17f
            setTextColor(Color.WHITE)
        }
        val toggle = android.widget.Switch(this).apply {
            isChecked = prefs.getBoolean(key, default)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() }
        }
        row.addView(text, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(toggle)
        parent.addView(row, lp())
    }

    private fun updateStatus() {
        val accessibilityOn = isAccessibilityServiceEnabled()
        val text = SpannableString("Accessibility: ${if (accessibilityOn) "ON" else "OFF"}")
        text.setSpan(ForegroundColorSpan(if (accessibilityOn) Color.GREEN else Color.RED), 15, 18, 0)
        statusText.text = text
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val manager = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabled = manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        val target = ComponentName(this, InstaAccessibilityService::class.java)
        return enabled.any { it.resolveInfo.serviceInfo.let { s -> ComponentName(s.packageName, s.name) == target } }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp(top: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply {
        if (top != 0 || bottom != 0) setMargins(0, dp(top), 0, dp(bottom))
    }
}
